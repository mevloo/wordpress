<?php
/**
 * The front page template file
 */

get_header();
?>

<div class="hero-section">
    <div class="container">
        <div class="hero-content">
            <h1 class="hero-title"><?php echo esc_html(get_theme_mod('hero_title', 'Crafting Digital Experiences')); ?></h1>
            <p class="hero-description"><?php echo esc_html(get_theme_mod('hero_description', 'We create innovative digital solutions that transform businesses and engage users.')); ?></p>
            <div class="hero-buttons">
                <a href="#contact" class="btn btn-primary"><?php esc_html_e('Start a Project', 'modern-agency'); ?></a>
                <a href="#services" class="btn btn-secondary"><?php esc_html_e('Our Services', 'modern-agency'); ?></a>
            </div>
        </div>
    </div>
    <div id="hero-3d-canvas"></div>
</div>

<section id="services" class="services-section">
    <div class="container">
        <h2 class="section-title"><?php esc_html_e('Our Services', 'modern-agency'); ?></h2>
        <div class="services-grid">
            <div class="service-card">
                <div class="service-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                        <line x1="8" y1="21" x2="16" y2="21"></line>
                        <line x1="12" y1="17" x2="12" y2="21"></line>
                    </svg>
                </div>
                <h3><?php esc_html_e('Web Development', 'modern-agency'); ?></h3>
                <p><?php esc_html_e('Custom websites and web applications built with modern technologies.', 'modern-agency'); ?></p>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
                    </svg>
                </div>
                <h3><?php esc_html_e('UI/UX Design', 'modern-agency'); ?></h3>
                <p><?php esc_html_e('User-centered design that creates engaging digital experiences.', 'modern-agency'); ?></p>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                        <polyline points="22,6 12,13 2,6"></polyline>
                    </svg>
                </div>
                <h3><?php esc_html_e('Digital Marketing', 'modern-agency'); ?></h3>
                <p><?php esc_html_e('Strategic marketing solutions to grow your online presence.', 'modern-agency'); ?></p>
            </div>
        </div>
    </div>
</section>

<section id="portfolio" class="portfolio-section">
    <div class="container">
        <h2 class="section-title"><?php esc_html_e('Featured Work', 'modern-agency'); ?></h2>
        <div class="portfolio-grid">
            <?php
            $args = array(
                'post_type' => 'portfolio',
                'posts_per_page' => 6
            );
            $portfolio_query = new WP_Query($args);
            
            if ($portfolio_query->have_posts()) :
                while ($portfolio_query->have_posts()) : $portfolio_query->the_post();
                    ?>
                    <div class="portfolio-item">
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="portfolio-image">
                                <?php the_post_thumbnail('large'); ?>
                            </div>
                        <?php endif; ?>
                        <div class="portfolio-content">
                            <h3><?php the_title(); ?></h3>
                            <p><?php echo get_the_excerpt(); ?></p>
                            <a href="<?php the_permalink(); ?>" class="btn btn-text"><?php esc_html_e('View Project', 'modern-agency'); ?></a>
                        </div>
                    </div>
                    <?php
                endwhile;
                wp_reset_postdata();
            endif;
            ?>
        </div>
    </div>
</section>

<section id="contact" class="contact-section">
    <div class="container">
        <h2 class="section-title"><?php esc_html_e('Start a Project', 'modern-agency'); ?></h2>
        <div class="contact-grid">
            <div class="contact-info">
                <h3><?php esc_html_e('Get in Touch', 'modern-agency'); ?></h3>
                <p><?php esc_html_e('Ready to bring your ideas to life? Contact us today.', 'modern-agency'); ?></p>
                <div class="contact-details">
                    <div class="contact-item">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        <span><?php echo esc_html(get_theme_mod('contact_phone', '+1 234 567 890')); ?></span>
                    </div>
                    <div class="contact-item">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                            <polyline points="22,6 12,13 2,6"></polyline>
                        </svg>
                        <span><?php echo esc_html(get_theme_mod('contact_email', 'hello@example.com')); ?></span>
                    </div>
                </div>
            </div>
            <div class="contact-form">
                <?php echo do_shortcode('[contact-form-7 id="' . get_theme_mod('contact_form_id', '') . '"]'); ?>
            </div>
        </div>
    </div>
</section>

<?php
get_footer();
?>