<?php
/**
 * Modern Agency Theme functions and definitions
 */

if (!defined('MODERN_AGENCY_VERSION')) {
    define('MODERN_AGENCY_VERSION', '1.0.0');
}

/**
 * Theme Setup
 */
function modern_agency_setup() {
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');

    // Let WordPress manage the document title
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails
    add_theme_support('post-thumbnails');

    // Register Navigation Menus
    register_nav_menus(array(
        'primary' => esc_html__('Primary Menu', 'modern-agency'),
        'footer' => esc_html__('Footer Menu', 'modern-agency'),
    ));

    // Add theme support for selective refresh for widgets
    add_theme_support('customize-selective-refresh-widgets');

    // Add support for Elementor
    add_theme_support('elementor');
}
add_action('after_setup_theme', 'modern_agency_setup');

/**
 * Enqueue scripts and styles
 */
function modern_agency_scripts() {
    // Enqueue Google Fonts
    wp_enqueue_style('modern-agency-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', array(), null);

    // Enqueue theme stylesheet
    wp_enqueue_style('modern-agency-style', get_stylesheet_uri(), array(), MODERN_AGENCY_VERSION);

    // Enqueue theme JavaScript
    wp_enqueue_script('modern-agency-navigation', get_template_directory_uri() . '/js/navigation.js', array(), MODERN_AGENCY_VERSION, true);

    // Enqueue custom 3D effects
    wp_enqueue_script('modern-agency-3d', get_template_directory_uri() . '/js/3d-effects.js', array('three'), MODERN_AGENCY_VERSION, true);

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'modern_agency_scripts');

/**
 * Register widget areas
 */
function modern_agency_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Sidebar', 'modern-agency'),
        'id'            => 'sidebar-1',
        'description'   => esc_html__('Add widgets here.', 'modern-agency'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'modern_agency_widgets_init');

/**
 * Elementor compatibility
 */
function modern_agency_elementor_support() {
    update_option('elementor_disable_color_schemes', 'yes');
    update_option('elementor_disable_typography_schemes', 'yes');
    update_option('elementor_page_title_selector', 'h1.entry-title');
    update_option('elementor_container_width', '1280');
    update_option('elementor_viewport_lg', '1025');
    update_option('elementor_viewport_md', '768');
}
add_action('after_switch_theme', 'modern_agency_elementor_support');

/**
 * Custom template tags
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions
 */
require get_template_directory() . '/inc/customizer.php';