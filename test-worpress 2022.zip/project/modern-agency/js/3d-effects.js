/**
 * 3D effects using Three.js
 */
import * as THREE from 'three';

class Scene3D {
    constructor() {
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.renderer = new THREE.WebGLRenderer({ alpha: true });
        
        this.init();
        this.animate();
    }

    init() {
        // Setup renderer
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        document.querySelector('.hero-section').appendChild(this.renderer.domElement);

        // Add ambient light
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);

        // Add directional light
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(0, 10, 10);
        this.scene.add(directionalLight);

        // Create geometric shapes
        this.createShapes();

        // Position camera
        this.camera.position.z = 5;

        // Handle window resize
        window.addEventListener('resize', () => this.onWindowResize(), false);
    }

    createShapes() {
        // Create multiple geometric shapes
        const shapes = [];
        
        // Cube
        const cubeGeometry = new THREE.BoxGeometry(1, 1, 1);
        const cubeMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x2563eb,
            flatShading: true
        });
        const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
        cube.position.set(-2, 0, 0);
        shapes.push(cube);

        // Sphere
        const sphereGeometry = new THREE.SphereGeometry(0.5, 32, 32);
        const sphereMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x1e40af,
            flatShading: true
        });
        const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
        sphere.position.set(2, 0, 0);
        shapes.push(sphere);

        // Torus
        const torusGeometry = new THREE.TorusGeometry(0.3, 0.2, 16, 100);
        const torusMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x3b82f6,
            flatShading: true
        });
        const torus = new THREE.Mesh(torusGeometry, torusMaterial);
        torus.position.set(0, 2, 0);
        shapes.push(torus);

        // Add shapes to scene
        shapes.forEach(shape => {
            this.scene.add(shape);
            shape.rotation.x = Math.random() * Math.PI;
            shape.rotation.y = Math.random() * Math.PI;
        });

        // Store shapes for animation
        this.shapes = shapes;
    }

    animate() {
        requestAnimationFrame(() => this.animate());

        // Rotate shapes
        this.shapes.forEach(shape => {
            shape.rotation.x += 0.01;
            shape.rotation.y += 0.01;
        });

        // Add floating animation
        const time = Date.now() * 0.001;
        this.shapes.forEach((shape, index) => {
            shape.position.y += Math.sin(time + index) * 0.01;
        });

        this.renderer.render(this.scene, this.camera);
    }

    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }
}

// Initialize 3D scene when document is loaded
document.addEventListener('DOMContentLoaded', () => {
    new Scene3D();
});