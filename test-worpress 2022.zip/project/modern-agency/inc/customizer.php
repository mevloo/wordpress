<?php
/**
 * Modern Agency Theme Customizer
 */

function modern_agency_customize_register($wp_customize) {
    // Add section for theme colors
    $wp_customize->add_section('modern_agency_colors', array(
        'title'    => __('Theme Colors', 'modern-agency'),
        'priority' => 30,
    ));

    // Primary Color
    $wp_customize->add_setting('primary_color', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'primary_color', array(
        'label'    => __('Primary Color', 'modern-agency'),
        'section'  => 'modern_agency_colors',
        'settings' => 'primary_color',
    )));

    // Secondary Color
    $wp_customize->add_setting('secondary_color', array(
        'default'           => '#1e40af',
        'sanitize_callback' => 'sanitize_hex_color',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'secondary_color', array(
        'label'    => __('Secondary Color', 'modern-agency'),
        'section'  => 'modern_agency_colors',
        'settings' => 'secondary_color',
    )));

    // Add section for header options
    $wp_customize->add_section('modern_agency_header', array(
        'title'    => __('Header Options', 'modern-agency'),
        'priority' => 40,
    ));

    // Sticky Header
    $wp_customize->add_setting('sticky_header', array(
        'default'           => true,
        'sanitize_callback' => 'modern_agency_sanitize_checkbox',
    ));

    $wp_customize->add_control('sticky_header', array(
        'label'    => __('Enable Sticky Header', 'modern-agency'),
        'section'  => 'modern_agency_header',
        'type'     => 'checkbox',
    ));

    // Add section for footer options
    $wp_customize->add_section('modern_agency_footer', array(
        'title'    => __('Footer Options', 'modern-agency'),
        'priority' => 50,
    ));

    // Footer Text
    $wp_customize->add_setting('footer_text', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));

    $wp_customize->add_control('footer_text', array(
        'label'    => __('Footer Text', 'modern-agency'),
        'section'  => 'modern_agency_footer',
        'type'     => 'textarea',
    ));

    // Add section for 3D effects
    $wp_customize->add_section('modern_agency_3d_effects', array(
        'title'    => __('3D Effects', 'modern-agency'),
        'priority' => 60,
    ));

    // Enable 3D Effects
    $wp_customize->add_setting('enable_3d_effects', array(
        'default'           => true,
        'sanitize_callback' => 'modern_agency_sanitize_checkbox',
    ));

    $wp_customize->add_control('enable_3d_effects', array(
        'label'    => __('Enable 3D Effects', 'modern-agency'),
        'section'  => 'modern_agency_3d_effects',
        'type'     => 'checkbox',
    ));
}
add_action('customize_register', 'modern_agency_customize_register');

/**
 * Sanitize checkbox values
 */
function modern_agency_sanitize_checkbox($checked) {
    return ((isset($checked) && true == $checked) ? true : false);
}

/**
 * Render the CSS for customizer options
 */
function modern_agency_customizer_css() {
    ?>
    <style type="text/css">
        :root {
            --primary-color: <?php echo esc_attr(get_theme_mod('primary_color', '#2563eb')); ?>;
            --secondary-color: <?php echo esc_attr(get_theme_mod('secondary_color', '#1e40af')); ?>;
        }
    </style>
    <?php
}
add_action('wp_head', 'modern_agency_customizer_css');