<?php
/**
 * Register custom post types
 */

function modern_agency_register_post_types() {
    // Portfolio Post Type
    $labels = array(
        'name'                  => _x('Portfolio', 'Post type general name', 'modern-agency'),
        'singular_name'         => _x('Portfolio Item', 'Post type singular name', 'modern-agency'),
        'menu_name'            => _x('Portfolio', 'Admin Menu text', 'modern-agency'),
        'add_new'              => __('Add New', 'modern-agency'),
        'add_new_item'         => __('Add New Portfolio Item', 'modern-agency'),
        'edit_item'            => __('Edit Portfolio Item', 'modern-agency'),
        'new_item'             => __('New Portfolio Item', 'modern-agency'),
        'view_item'            => __('View Portfolio Item', 'modern-agency'),
        'search_items'         => __('Search Portfolio', 'modern-agency'),
        'not_found'            => __('No portfolio items found', 'modern-agency'),
        'not_found_in_trash'   => __('No portfolio items found in Trash', 'modern-agency'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'portfolio'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-portfolio',
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest'       => true,
    );

    register_post_type('portfolio', $args);
}
add_action('init', 'modern_agency_register_post_types');