<?php
namespace ModernAgency\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Animated_Heading extends Widget_Base {

    public function get_name() {
        return 'animated-heading';
    }

    public function get_title() {
        return __('Animated Heading', 'modern-agency');
    }

    public function get_icon() {
        return 'eicon-animated-headline';
    }

    public function get_categories() {
        return ['modern-agency'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'modern-agency'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'heading_text',
            [
                'label' => __('Heading Text', 'modern-agency'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Animated Heading', 'modern-agency'),
            ]
        );

        $this->add_control(
            'animated_text',
            [
                'label' => __('Animated Text', 'modern-agency'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __("First Line\nSecond Line\nThird Line", 'modern-agency'),
                'description' => __('Enter each text on a new line', 'modern-agency'),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Style', 'modern-agency'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'selector' => '{{WRAPPER}} .animated-heading',
            ]
        );

        $this->add_control(
            'heading_color',
            [
                'label' => __('Heading Color', 'modern-agency'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .animated-heading' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $animated_lines = explode("\n", $settings['animated_text']);
        ?>
        <h2 class="animated-heading">
            <?php echo esc_html($settings['heading_text']); ?>
            <span class="animated-text" data-words="<?php echo esc_attr(json_encode($animated_lines)); ?>"></span>
        </h2>
        <?php
    }
}